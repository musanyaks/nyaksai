import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

async function main() {
  const zai = await ZAI.create();
  const response = await zai.images.generations.create({
    prompt:
      'Ultra-wide dark tech hero banner for a stealth AI desktop assistant, sleek matte black background with subtle neon emerald green glowing accents, a translucent floating glass window panel hovering above a dark laptop screen showing faint code, ghost-like translucent UI, soft glow, cinematic lighting, minimalist futuristic design, high quality, detailed, no text',
    size: '1344x768',
  });
  const b64 = response.data[0].base64;
  fs.writeFileSync('public/readme-banner.png', Buffer.from(b64, 'base64'));
  console.log('written public/readme-banner.png');
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
