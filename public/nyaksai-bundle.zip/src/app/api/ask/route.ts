import { NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export const runtime = 'nodejs'
export const maxDuration = 300

interface AskMessage {
  role: 'user' | 'assistant'
  text: string
}

interface AskRequestBody {
  messages?: AskMessage[]
  images?: string[] // data URLs (image/jpeg;base64,...)
  systemPrompt?: string
  context?: string
  provider?: { baseUrl?: string; apiKey?: string; model?: string }
}

interface ProviderConfig {
  baseUrl: string
  apiKey: string
  model: string
}

/** Valid BYOK config from the request body, or null when absent. */
function providerFrom(body: AskRequestBody): ProviderConfig | null {
  const p = body.provider
  if (!p?.apiKey || !p.baseUrl) return null
  return {
    baseUrl: p.baseUrl.trim().replace(/\/+$/, ''),
    apiKey: p.apiKey,
    model: p.model?.trim() || 'gpt-4o-mini',
  }
}

/** SSE frames sent to the client: {"t": "..."} chunks, {"suggestions": []}, {"done": true}, {"error": "..."} */
function sse(controller: ReadableStreamDefaultController, payload: unknown) {
  controller.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(payload)}\n\n`))
}

/** OpenAI-compatible message array (proper 'system' role + image parts on the last user turn). */
function providerMessages(systemContent: string, history: AskMessage[], images: string[]) {
  const msgs: Record<string, unknown>[] = [{ role: 'system', content: systemContent }]
  history.forEach((m, idx) => {
    const isLast = idx === history.length - 1
    if (isLast && images.length > 0) {
      msgs.push({
        role: 'user',
        content: [
          { type: 'text', text: m.text || 'Look at the attached screenshot(s) and answer.' },
          ...images.map((url) => ({ type: 'image_url', image_url: { url } })),
        ],
      })
    } else {
      msgs.push({ role: m.role, content: m.text })
    }
  })
  return msgs
}

/** Stream an answer from any OpenAI-compatible /chat/completions endpoint. */
async function streamFromProvider(
  provider: ProviderConfig,
  apiMessages: Record<string, unknown>[],
  onDelta: (text: string) => void
): Promise<string> {
  let res: Response
  try {
    res = await fetch(`${provider.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${provider.apiKey}`,
      },
      body: JSON.stringify({ model: provider.model, messages: apiMessages, stream: true }),
    })
  } catch (e) {
    throw new Error(
      `Could not reach ${provider.baseUrl} — check the Base URL and your connection. (${e instanceof Error ? e.message : 'network error'})`
    )
  }
  if (!res.ok || !res.body) {
    const detail = await res.text().catch(() => '')
    if (res.status === 401) {
      throw new Error(
        'Your API key was rejected (401 "token expired or incorrect"). The key must belong to the same platform as the Base URL: keys from z.ai → https://api.z.ai/api/paas/v4; keys from open.bigmodel.cn → https://open.bigmodel.cn/api/paas/v4; GLM Coding Plan keys → https://api.z.ai/api/coding/paas/v4. Re-copy the key with no spaces and make sure it is still active in your console.'
      )
    }
    throw new Error(
      `Provider error ${res.status}: ${detail.slice(0, 300) || res.statusText}`
    )
  }
  return pipeUpstream(res.body, onDelta)
}

/** Follow-up chips generated from the actual answer via the custom provider. */
async function providerSuggestions(
  provider: ProviderConfig,
  lastQuestion: string,
  answer: string
): Promise<string[]> {
  try {
    const res = await fetch(`${provider.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${provider.apiKey}`,
      },
      body: JSON.stringify({
        model: provider.model,
        stream: false,
        messages: [
          {
            role: 'system',
            content:
              'You generate short follow-up questions. Output exactly 3 follow-up questions, one per line, no numbering, no quotes, each under 8 words.',
          },
          {
            role: 'user',
            content: `Question asked:\n${lastQuestion.slice(0, 800)}\n\nAnswer given:\n${answer.slice(0, 1500)}\n\nOutput the 3 follow-up questions now.`,
          },
        ],
      }),
    })
    if (!res.ok) return []
    const j = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> }
    return (j.choices?.[0]?.message?.content ?? '')
      .split('\n')
      .map((l) => l.replace(/^[-*\d.)\s]+/, '').trim())
      .filter((l) => l.length > 3 && l.length < 90)
      .slice(0, 3)
  } catch {
    return []
  }
}

/**
 * Chat completion with streaming against the built-in backend (used when no
 * custom provider is configured — e.g. the hosted preview).
 * Returns the upstream ReadableStream when streaming is available.
 */
async function createChat(
  zai: Awaited<ReturnType<typeof ZAI.create>>,
  apiMessages: Record<string, unknown>[]
): Promise<unknown> {
  return await zai.chat.completions.create({
    messages: apiMessages,
    stream: true,
    thinking: { type: 'disabled' },
  } as never)
}

/** Pull text deltas out of the upstream SSE stream and forward them downstream. */
async function pipeUpstream(
  upstream: ReadableStream<Uint8Array>,
  onDelta: (text: string) => void
): Promise<string> {
  const reader = upstream.getReader()
  const dec = new TextDecoder()
  let buf = ''
  let answer = ''
  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    buf += dec.decode(value, { stream: true })
    let idx: number
    while ((idx = buf.indexOf('\n')) !== -1) {
      const line = buf.slice(0, idx).trim()
      buf = buf.slice(idx + 1)
      if (!line.startsWith('data:')) continue
      const payload = line.slice(5).trim()
      if (!payload || payload === '[DONE]') continue
      try {
        const j = JSON.parse(payload) as {
          choices?: Array<{ delta?: { content?: string }; message?: { content?: string } }>
        }
        const delta =
          j.choices?.[0]?.delta?.content ?? j.choices?.[0]?.message?.content ?? ''
        if (delta) {
          answer += delta
          onDelta(delta)
        }
      } catch {
        /* partial json line — ignore */
      }
    }
  }
  return answer
}

/** Generate 3 real follow-up chips from the actual question + answer. */
async function generateSuggestions(
  zai: Awaited<ReturnType<typeof ZAI.create>>,
  lastQuestion: string,
  answer: string
): Promise<string[]> {
  try {
    const completion = (await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content:
            'You generate short follow-up questions. Output exactly 3 follow-up questions, one per line, no numbering, no quotes, each under 8 words.',
        },
        {
          role: 'user',
          content: `Question asked:\n${lastQuestion.slice(0, 800)}\n\nAnswer given:\n${answer.slice(0, 1500)}\n\nOutput the 3 follow-up questions now.`,
        },
      ],
      thinking: { type: 'disabled' },
    })) as { choices?: Array<{ message?: { content?: string } }> }
    const raw = completion.choices?.[0]?.message?.content ?? ''
    const lines = raw
      .split('\n')
      .map((l) => l.replace(/^[-*\d.)\s]+/, '').trim())
      .filter((l) => l.length > 3 && l.length < 90)
    return lines.slice(0, 3)
  } catch {
    return []
  }
}

export async function POST(request: Request) {
  let body: AskRequestBody
  try {
    body = (await request.json()) as AskRequestBody
  } catch {
    return NextResponse.json({ success: false, error: 'Invalid request body.' }, { status: 400 })
  }

  const history = Array.isArray(body.messages) ? body.messages.slice(-12) : []
  const images = (body.images ?? []).filter((i) => i.startsWith('data:')).slice(0, 3)

  if (history.length === 0 && images.length === 0) {
    return NextResponse.json(
      { success: false, error: 'Nothing to answer — send a question or a screenshot.' },
      { status: 400 }
    )
  }

  const provider = providerFrom(body)

  const systemContent = [
    body.systemPrompt?.trim() ||
      'You are Nyaksai, an invisible real-time assistant helping during live technical interviews, calls and exams. Answer instantly and confidently.',
    body.context ? `Live conversation context:\n${body.context}` : '',
  ]
    .filter(Boolean)
    .join('\n\n')

  const apiMessages: Record<string, unknown>[] = [
    { role: 'assistant', content: systemContent },
    ...history.map((m, idx) => {
      const isLast = idx === history.length - 1
      if (isLast && images.length > 0) {
        return {
          role: 'user',
          content: [
            { type: 'text', text: m.text || 'Look at the attached screenshot(s) and answer.' },
            ...images.map((url) => ({ type: 'image_url', image_url: { url } })),
          ],
        }
      }
      return { role: m.role, content: m.text }
    }),
  ]

  const useVision = images.length > 0
  const lastUser = [...history].reverse().find((m) => m.role === 'user')?.text ?? 'Screenshot question'

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        let answer = ''

        // ── BYOK: the user's own OpenAI-compatible endpoint (desktop bundle / local runs) ──
        if (provider) {
          try {
            answer = await streamFromProvider(
              provider,
              providerMessages(systemContent, history, images),
              (delta) => sse(controller, { t: delta })
            )
          } catch (e) {
            const msg = e instanceof Error ? e.message : 'Custom provider request failed.'
            console.error('[POST /api/ask] custom provider:', msg)
            sse(controller, { error: msg })
            return
          }
          if (!answer.trim()) {
            sse(controller, { error: 'Your provider returned an empty answer.' })
            return
          }
          sse(controller, { suggestions: await providerSuggestions(provider, lastUser, answer) })
          sse(controller, { done: true })
          return
        }

        const zai = await ZAI.create()
        if (useVision) {
          // Vision endpoint answers in one shot (real API, no SSE upstream)
          const completion = (await zai.chat.completions.createVision({
            messages: apiMessages as never,
            thinking: { type: 'disabled' },
          } as never)) as { choices?: Array<{ message?: { content?: string } }> }
          answer = completion.choices?.[0]?.message?.content ?? ''
          if (!answer.trim()) throw new Error('The vision model returned an empty answer.')
          sse(controller, { t: answer })
        } else {
          const upstream = await createChat(zai, apiMessages)
          if (upstream && typeof (upstream as ReadableStream).getReader === 'function') {
            answer = await pipeUpstream(upstream as ReadableStream<Uint8Array>, (delta) =>
              sse(controller, { t: delta })
            )
          } else {
            const j = upstream as { choices?: Array<{ message?: { content?: string } }> }
            answer = j.choices?.[0]?.message?.content ?? ''
            if (!answer.trim()) throw new Error('The model returned an empty answer.')
            sse(controller, { t: answer })
          }
          if (!answer.trim()) throw new Error('The model returned an empty answer.')
        }

        const suggestions = await generateSuggestions(zai, lastUser, answer)
        sse(controller, { suggestions })
        sse(controller, { done: true })
      } catch (error) {
        console.error('[POST /api/ask]', error)
        sse(controller, {
          error: 'The assistant could not answer. Please try again.',
        })
      } finally {
        controller.close()
      }
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
    },
  })
}
