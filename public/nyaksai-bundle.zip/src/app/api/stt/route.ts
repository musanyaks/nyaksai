import { NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export const runtime = 'nodejs'
export const maxDuration = 120

const MAX_BYTES = 25 * 1024 * 1024 // 25 MB of audio is plenty for utterances

/**
 * POST /api/stt — real speech-to-text via the built-in ASR model.
 * Accepts either multipart/form-data with an `audio` file (Blob) or
 * JSON { audio_base64 } / { audio: dataURL }. Returns { success, text }.
 */
export async function POST(request: Request) {
  try {
    let base64: string | null = null
    let provider: { baseUrl: string; apiKey: string; model: string } | null = null

    const contentType = request.headers.get('content-type') ?? ''
    if (contentType.includes('multipart/form-data')) {
      const form = await request.formData()
      const file = form.get('audio')
      // BYOK fields appended by the client when a custom provider is enabled.
      const pBase = form.get('providerBaseUrl')
      const pKey = form.get('providerApiKey')
      const pModel = form.get('providerModel')
      if (typeof pBase === 'string' && typeof pKey === 'string' && pBase && pKey) {
        provider = {
          baseUrl: pBase.trim().replace(/\/+$/, ''),
          apiKey: pKey,
          model: (typeof pModel === 'string' && pModel.trim()) || 'whisper-1',
        }
      }
      if (!(file instanceof Blob)) {
        return NextResponse.json(
          { success: false, error: 'No audio file received.' },
          { status: 400 }
        )
      }
      if (file.size === 0) {
        return NextResponse.json({ success: false, error: 'Empty audio.' }, { status: 400 })
      }
      if (file.size > MAX_BYTES) {
        return NextResponse.json(
          { success: false, error: 'Audio clip too large (max 25 MB).' },
          { status: 413 }
        )
      }
      const buf = Buffer.from(await file.arrayBuffer())
      base64 = buf.toString('base64')
    } else {
      const body = (await request.json()) as {
        audio_base64?: string
        audio?: string
        provider?: { baseUrl?: string; apiKey?: string; model?: string }
      }
      if (body.provider?.baseUrl && body.provider?.apiKey) {
        provider = {
          baseUrl: body.provider.baseUrl.trim().replace(/\/+$/, ''),
          apiKey: body.provider.apiKey,
          model: body.provider.model?.trim() || 'whisper-1',
        }
      }
      const raw = body.audio_base64 ?? body.audio ?? ''
      if (!raw) {
        return NextResponse.json(
          { success: false, error: 'No audio payload received.' },
          { status: 400 }
        )
      }
      base64 = raw.includes(',') && raw.startsWith('data:') ? raw.split(',')[1] : raw
    }

    if (!base64) {
      return NextResponse.json({ success: false, error: 'No audio payload.' }, { status: 400 })
    }

    // ── BYOK: forward to the user's own OpenAI-compatible /audio/transcriptions ──
    if (provider) {
      const upstream = new FormData()
      upstream.append(
        'file',
        new Blob([Buffer.from(base64, 'base64')], { type: 'audio/wav' }),
        'audio.wav'
      )
      upstream.append('model', provider.model)
      let r: Response
      try {
        r = await fetch(`${provider.baseUrl}/audio/transcriptions`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${provider.apiKey}` },
          body: upstream,
        })
      } catch {
        return NextResponse.json(
          {
            success: false,
            error: `Could not reach ${provider.baseUrl} — check the Base URL and your connection.`,
          },
          { status: 502 }
        )
      }
      if (!r.ok) {
        const detail = await r.text().catch(() => '')
        if (r.status === 401) {
          return NextResponse.json(
            {
              success: false,
              error:
                'Your API key was rejected (401). The key must belong to the same platform as the Base URL — z.ai keys → https://api.z.ai/api/paas/v4, open.bigmodel.cn keys → https://open.bigmodel.cn/api/paas/v4. Re-copy the key with no spaces and make sure it is still active.',
            },
            { status: 502 }
          )
        }
        return NextResponse.json(
          {
            success: false,
            error: `Provider transcription error ${r.status}: ${detail.slice(0, 200)}`,
          },
          { status: 502 }
        )
      }
      const j = (await r.json()) as { text?: string }
      return NextResponse.json({ success: true, text: (j.text ?? '').trim() })
    }

    const zai = await ZAI.create()
    const result = (await zai.audio.asr.create({ file_base64: base64 })) as { text?: string }
    const text = (result?.text ?? '').trim()

    return NextResponse.json({ success: true, text })
  } catch (error) {
    console.error('[POST /api/stt]', error)
    return NextResponse.json(
      { success: false, error: 'Transcription failed. Please try again.' },
      { status: 500 }
    )
  }
}
